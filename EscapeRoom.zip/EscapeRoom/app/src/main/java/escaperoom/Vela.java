package main.java.escaperoom;

public class Vela {
    private boolean acesa = false;
    
    public boolean estaAcesa() { return this.acesa; }

    public String acender() { this.acesa = true; return "A vela foi acessa e iluminou o quarto, voce consegue ver a seguinte mensagem na parede: \n-Derrame a cera da vela na chave para poder usa-la na porta- \n"; }

    public void derramarCera(Key key) { 
        // Supondo que a variável se chama 'acesa' em vez de 'acessa'
        if(this.acesa && key.estaQuebrada()) {
            key.lubrificar();
            System.out.println("A chave foi lubrificada!");
        } else {
            System.out.println("A chave está quebrada! ");
        }
    }
}

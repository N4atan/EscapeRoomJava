package main.java.escaperoom;

public class Key {
    private boolean lubrificada = false;
    private boolean inteira = true;

    public boolean estaQuebrada()    { return this.inteira;    }
    public boolean estaLubrificada() { return this.lubrificada; }

    public void quebrar() { this.inteira = false; System.out.println("A chave foi quebrada!"); }

    public void lubrificar() { this.lubrificada = true; }

    public void usar() {
        System.out.println("Voce conseguiu destrancar a porta! ");
    }
}

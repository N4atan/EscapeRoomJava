package main.java.escaperoom;

public class Espelho {
    private String codigo;
}
